package com.example.tp2;

import androidx.appcompat.app.AppCompatActivity;
import static android.provider.AlarmClock.EXTRA_MESSAGE;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class showme extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showme);
        Intent intent = getIntent();
        String message = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        TextView textView = findViewById(R.id.result);
        textView.setText(message);
    }
}