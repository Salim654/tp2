package com.example.tp2;

import android.content.Intent;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.google.type.DateTime;



public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE ="";
    private DateTime time ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText text;
        Button show,lorey,calen;
        show=(Button)findViewById(R.id.show);
        lorey=(Button)findViewById(R.id.lorey);
        calen=(Button)findViewById(R.id.calen);
        text=(EditText)findViewById(R.id.text1);
       show.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(getApplicationContext(),showme.class);
               String message = text.getText().toString();
               intent.putExtra(EXTRA_MESSAGE, message);
               startActivity(intent);
           }
       });
       lorey.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(getApplicationContext(),lorem.class);
               startActivity(intent);
           }
       });
       calen.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(Intent.ACTION_EDIT);
               intent.setType("vnd.android.cursor.item/event");
               intent.putExtra(CalendarContract.Events.TITLE, "Event Title");
               intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, 8/10/2022);
               intent.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, 9/10/2022);
               intent.putExtra(CalendarContract.Events.ALL_DAY, false);
               intent.putExtra(CalendarContract.Events.DESCRIPTION, "Event Descripttion");
               intent.putExtra(CalendarContract.Events.EVENT_LOCATION, "Event Location");
               startActivity(Intent.createChooser(intent, "Add to calendar"));
           }
       });
    }
}